// Toggle visibility of the chatbot widget when the chatbot icon is clicked
const chatbotWidget = document.querySelector('.chatbot-widget');
const chatbotIcon = document.querySelector('.chatbot-icon');
const sendButton = document.getElementById('send-btn');
const userInput = document.getElementById('user-input');
const chatBox = document.getElementById('chat-box');

// Toggle the chatbot window visibility
chatbotIcon.addEventListener('click', () => {
    chatbotWidget.classList.toggle('open');
});

// Send the user's message and get a response from the backend
sendButton.addEventListener('click', async function () {
    const userMessage = userInput.value.trim();

    if (userMessage) {
        // Display user's message
        appendMessage(userMessage, 'user');
        userInput.value = '';  // Clear input box

        // Get chatbot's response
        const response = await getChatbotResponse(userMessage);

        // Display bot's response
        appendMessage(response, 'bot');
    }
});

// Function to call the backend (Flask API)
async function getChatbotResponse(userMessage) {
    try {
        const response = await fetch('http://127.0.0.1:5000/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message: userMessage })
        });

        const data = await response.json();
        return data.response || "Sorry, I couldn't understand that.";
    } catch (error) {
        console.error('Error:', error);
        return "Oops! Something went wrong.";
    }
}

// Append messages to the chatbox
function appendMessage(message, sender) {
    const messageElement = document.createElement('div');
    messageElement.classList.add('chat-message', `${sender}-message`);
    messageElement.textContent = message;
    chatBox.appendChild(messageElement);

    chatBox.scrollTop = chatBox.scrollHeight;  // Scroll to the bottom
}
